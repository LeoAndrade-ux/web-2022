"use scrict";
var anio = 2010;
while (anio <= 2020) {
    console.log("El anio actual es " + anio);
    if (anio >= 2010) {
        anio++;
    }
}
