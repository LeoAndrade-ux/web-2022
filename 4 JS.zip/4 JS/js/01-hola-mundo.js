alert("Hola mundo");
document.write("<h2>Bienvenidos a mi pagina</h2>");