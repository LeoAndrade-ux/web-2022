'use strict'
//bucle for permite repeticiones
var numero=3;
for (let i = 0; i < 10; i++) {
    console.log(numero);
}