//comentarios de una linea
/*Comentarios varias lineas*/


/*Directiva  que permite programar de forma correcta
permite activar funcionalidades de js*/

'use strict'
var nombre='Daniel';
console.log(nombre);
var pais='Ecuador';
var continente="America Sur";
var anio=2022;
var paisAnio= pais+ " - " + anio;
console.log(paisAnio);
pais="Italia"
console.log(pais);
/*Declaracion de variales let o var*/
let nombre2="Leonardo"
console.log(nombre2);