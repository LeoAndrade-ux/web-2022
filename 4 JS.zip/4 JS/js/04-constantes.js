"use strict";
var numero = 3;
numero = 5;
const pi = 3.141516;
console.log(numero);
console.log(pi);
pi = pi + numero;
console.log(pi);
