'use strict'
var edad = 18;
switch(edad){
    case 18:
        console.log("Eres mayor de edad");
        break;
    case 25:
        console.log("Eres adulto");
        break;
    case 50:
        console.log("Eres un adulto mayor");
        break;
    case 80:
        console.log("Eres de la tercera edad");
        break;
    default:
        console.log("Tu edad no esta especificada")
}