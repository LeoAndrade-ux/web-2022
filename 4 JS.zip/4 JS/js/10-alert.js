'use strict'
//alerta
alert("Esto es una alerta");
alert("Prueba 2")

//confirmacion
var resultado = confirm("Desas continuar");
console.log(resultado);

//ingreso de datos

var resultado1=prompt("¿Qué edad tienes?");
console.log(typeof resultado1);